import random
maze = True
score = 0
while maze:
    event = random.randint(1,4)
    
    direction = input("Do you go forward, backward, left or right?")
    
    if event == 1:
        print("You take a step",direction)
    elif event == 2:
        print("A wall blocks your path.")
    elif event == 3:
        print("You find a chest you gain 5 points")
        score = score + 5
        print("You now have",score,"points.")
    elif event == 4:
        question = int(input("You find a door do you want to continue your journey(1) or exit(2)?"))
        if question == 1:
            print("You take a step away from the door.")
        elif question == 2:
            print("You walk through the door.")
            print("Your final score is",score)